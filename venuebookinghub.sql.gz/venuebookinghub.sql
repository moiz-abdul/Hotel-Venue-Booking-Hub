-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2024 at 12:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `venuebookinghub`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add uzerlogin', 7, 'add_uzerlogin'),
(26, 'Can change uzerlogin', 7, 'change_uzerlogin'),
(27, 'Can delete uzerlogin', 7, 'delete_uzerlogin'),
(28, 'Can view uzerlogin', 7, 'view_uzerlogin'),
(29, 'Can add password reset otp', 8, 'add_passwordresetotp'),
(30, 'Can change password reset otp', 8, 'change_passwordresetotp'),
(31, 'Can delete password reset otp', 8, 'delete_passwordresetotp'),
(32, 'Can view password reset otp', 8, 'view_passwordresetotp'),
(33, 'Can add user message', 9, 'add_usermessage'),
(34, 'Can change user message', 9, 'change_usermessage'),
(35, 'Can delete user message', 9, 'delete_usermessage'),
(36, 'Can view user message', 9, 'view_usermessage'),
(37, 'Can add filterdata', 10, 'add_filterdata'),
(38, 'Can change filterdata', 10, 'change_filterdata'),
(39, 'Can delete filterdata', 10, 'delete_filterdata'),
(40, 'Can view filterdata', 10, 'view_filterdata'),
(41, 'Can add user_information', 11, 'add_user_information'),
(42, 'Can change user_information', 11, 'change_user_information'),
(43, 'Can delete user_information', 11, 'delete_user_information'),
(44, 'Can view user_information', 11, 'view_user_information');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookinghubapp_filterdata`
--

CREATE TABLE `bookinghubapp_filterdata` (
  `id` bigint(20) NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Location` longtext NOT NULL,
  `Capacity_of_Guests` int(11) NOT NULL,
  `Rate` varchar(50) NOT NULL,
  `Address` longtext NOT NULL,
  `Contact` varchar(15) NOT NULL,
  `Event_Space` int(11) NOT NULL,
  `Image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookinghubapp_filterdata`
--

INSERT INTO `bookinghubapp_filterdata` (`id`, `Name`, `Location`, `Capacity_of_Guests`, `Rate`, `Address`, `Contact`, `Event_Space`, `Image`) VALUES
(1, 'Empire Marquee Islamabad ', 'Islamabad', 500, '1500 PKR / Per Person', 'Near PSO Pump, Kuri Road, Islamabad Expressway', '0300 5081917', 3, 'upload/20240218004923Isl_M1.jpg'),
(2, 'Mari Gold Marquee', 'Islamabad', 550, '1200 PKR / Per Person', 'National Hwy 5, Islamabad, Capital Territory', '0321 9580443', 3, 'upload/20240218005109Mari_Gold.jpg'),
(3, 'Events Marquee', 'Islamabad', 550, '1350 PKR / Per Person', 'Opposite NUST, Gate 2, H-13, Kashmir Highway, Islamabad.', '0333-0305555', 4, 'upload/20240218010032Events.jpg'),
(4, 'Imperial Marquee', 'Islamabad', 600, '1650', 'H-13, Main Kashmir Highway, Islamabad', '0316 1999555', 2, 'upload/20240219193834Imperal.jpg'),
(5, 'Taj Marquee Islamabad', 'Islamabad', 800, '12000', 'Opp Main Margalla Road, Express Highway, Islamabad', '0300 8566597', 2, 'upload/20240219194013Taj.jpg'),
(6, 'Jugnu Marquee', 'Islamabad', 450, '950', 'WildLife Park Chowk, Main Expressway, Islamabad', '0344 5510085', 1, 'upload/20240219194122Jugnu.jpeg'),
(7, 'Pavilion Marquee Islamabad', 'Islamabad', 750, '1100', 'Islamabad Expressway, behind PSO Burki Petrol Station, Islamabad', '0321 5019444', 2, 'upload/20240219194219Pavilion.jpg'),
(8, 'Kazani Resorts', 'Islamabad', 700, '3500', 'Islamabad Expressway, behind PSO Burki Petrol Station, Islamabad', '0317 5708994', 2, 'upload/20240219194508Kazani.jpg'),
(9, 'Sunset Resort', 'Islamabad', 650, '3000', 'Street # 4, Shah Allah Ditta, near D-12, Islamabad, Islamabad ', '0335 5738798', 1, 'upload/20240219194622Sunset.jpg'),
(10, 'Islamabad hill hotel and Cafe', 'Islamabad', 500, '2500', 'NP 87 LHW06 Shahdara, Valley Road, Islamabad ', '0313 5745241', 2, 'upload/20240219194723Islamabad_Hill_Hotel_and_Cafe.jpg'),
(11, 'Majestic Banquet Islamabad', 'Islamabad', 500, '1500', '2-A Club Rd، near Rwal Dam chowk, Shakar Parian, Islamabad', '0327 9731348', 1, 'upload/20240219194816Majestic_Banquet.jpg'),
(12, 'Royal Farm House', 'Islamabad', 450, '3500', 'Royal Farm House & Residencia, Chakri Rd, in front of Blue World City, Rawalpindi, Punjab', '0315 3231869', 4, 'upload/20240219194955Royal_Farm.jpg'),
(13, 'Blue Hills Farm House', 'Islamabad', 550, '3000', 'Blue Hills Farm House, Islamabad Motorway towards Rawalpindi', '0333 4141867', 3, 'upload/20240219195043BlueHills.jpg'),
(14, 'Mehar Palace Marquee', 'Lahore', 450, '1750', 'Main Canal Road, near PSO Petrol Pump, Fateh Garh Mughalpura, Lahore, Punjab 54000', '0321 1000806', 4, 'upload/20240221210950Mehar_Marquee.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `bookinghubapp_usermessage`
--

CREATE TABLE `bookinghubapp_usermessage` (
  `id` bigint(20) NOT NULL,
  `PersonName` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `Message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookinghubapp_user_information`
--

CREATE TABLE `bookinghubapp_user_information` (
  `id` bigint(20) NOT NULL,
  `First_name` varchar(100) NOT NULL,
  `Last_name` varchar(100) NOT NULL,
  `Phone_number` varchar(15) NOT NULL,
  `Email_address` varchar(50) NOT NULL,
  `Event_date` varchar(30) NOT NULL,
  `Event_time` varchar(30) NOT NULL,
  `No_of_Guests` int(11) NOT NULL,
  `Message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookinghubapp_user_information`
--

INSERT INTO `bookinghubapp_user_information` (`id`, `First_name`, `Last_name`, `Phone_number`, `Email_address`, `Event_date`, `Event_time`, `No_of_Guests`, `Message`) VALUES
(3, 'Bilal', 'Saeed', '0314 4547945', 'bilal123@gmail.com', '2024-02-29', '23:45', 400, 'Book krde bhai '),
(4, 'Ayesha', 'Shah', '0314 288 9522', 'ayesha123@gmail.com', '2024-03-22', '23:12', 300, 'Book this !!'),
(5, 'Zohaib', 'Ali', '0314 4349945', 'zaibi@gmail.com', '2024-03-22', '16:57', 400, 'Ker de yaar\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(10, 'BookingHubApp', 'filterdata'),
(8, 'BookingHubApp', 'passwordresetotp'),
(9, 'BookingHubApp', 'usermessage'),
(11, 'BookingHubApp', 'user_information'),
(7, 'BookingHubApp', 'uzerlogin'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'BookingHubApp', '0001_initial', '2024-02-17 15:37:36.291181'),
(2, 'BookingHubApp', '0002_passwordresetotp', '2024-02-17 15:37:36.433665'),
(3, 'BookingHubApp', '0003_passwordresetotp_otp_expire', '2024-02-17 15:37:36.465839'),
(4, 'BookingHubApp', '0004_alter_passwordresetotp_otp_expire', '2024-02-17 15:37:36.474315'),
(5, 'BookingHubApp', '0005_usermessage_alter_passwordresetotp_otp_expire', '2024-02-17 15:37:36.499245'),
(6, 'BookingHubApp', '0006_alter_passwordresetotp_otp_expire', '2024-02-17 15:37:36.517942'),
(7, 'BookingHubApp', '0007_alter_passwordresetotp_otp_expire', '2024-02-17 15:37:36.528153'),
(8, 'BookingHubApp', '0008_filterdata_alter_passwordresetotp_otp_expire', '2024-02-17 15:43:05.594098'),
(9, 'contenttypes', '0001_initial', '2024-02-17 15:43:05.694478'),
(10, 'auth', '0001_initial', '2024-02-17 15:43:06.664449'),
(11, 'admin', '0001_initial', '2024-02-17 15:43:06.829268'),
(12, 'admin', '0002_logentry_remove_auto_add', '2024-02-17 15:43:06.877874'),
(13, 'admin', '0003_logentry_add_action_flag_choices', '2024-02-17 15:43:06.895379'),
(14, 'contenttypes', '0002_remove_content_type_name', '2024-02-17 15:43:07.010378'),
(15, 'auth', '0002_alter_permission_name_max_length', '2024-02-17 15:43:07.099387'),
(16, 'auth', '0003_alter_user_email_max_length', '2024-02-17 15:43:07.118544'),
(17, 'auth', '0004_alter_user_username_opts', '2024-02-17 15:43:07.138429'),
(18, 'auth', '0005_alter_user_last_login_null', '2024-02-17 15:43:07.208785'),
(19, 'auth', '0006_require_contenttypes_0002', '2024-02-17 15:43:07.211164'),
(20, 'auth', '0007_alter_validators_add_error_messages', '2024-02-17 15:43:07.232117'),
(21, 'auth', '0008_alter_user_username_max_length', '2024-02-17 15:43:07.259684'),
(22, 'auth', '0009_alter_user_last_name_max_length', '2024-02-17 15:43:07.276783'),
(23, 'auth', '0010_alter_group_name_max_length', '2024-02-17 15:43:07.306180'),
(24, 'auth', '0011_update_proxy_permissions', '2024-02-17 15:43:07.332684'),
(25, 'auth', '0012_alter_user_first_name_max_length', '2024-02-17 15:43:07.370993'),
(26, 'sessions', '0001_initial', '2024-02-17 15:43:07.474233'),
(27, 'BookingHubApp', '0009_alter_passwordresetotp_otp_expire', '2024-02-17 19:48:45.726592'),
(28, 'BookingHubApp', '0010_user_information_alter_passwordresetotp_otp_expire', '2024-02-24 15:55:12.187339'),
(29, 'BookingHubApp', '0011_alter_passwordresetotp_otp_expire', '2024-02-24 16:20:05.848365'),
(30, 'BookingHubApp', '0012_alter_passwordresetotp_otp_expire', '2024-02-24 16:24:25.432581');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `bookinghubapp_filterdata`
--
ALTER TABLE `bookinghubapp_filterdata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookinghubapp_usermessage`
--
ALTER TABLE `bookinghubapp_usermessage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookinghubapp_user_information`
--
ALTER TABLE `bookinghubapp_user_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookinghubapp_filterdata`
--
ALTER TABLE `bookinghubapp_filterdata`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `bookinghubapp_usermessage`
--
ALTER TABLE `bookinghubapp_usermessage`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookinghubapp_user_information`
--
ALTER TABLE `bookinghubapp_user_information`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
